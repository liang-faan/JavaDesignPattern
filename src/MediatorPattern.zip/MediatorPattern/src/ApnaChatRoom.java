
public interface ApnaChatRoom {
	
	public void showMsg(String msg, Participant p);

}

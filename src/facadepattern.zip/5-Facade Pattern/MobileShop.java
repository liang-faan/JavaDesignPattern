
public interface MobileShop {
	
	
	public void modelNo();
	
	public void price();

}

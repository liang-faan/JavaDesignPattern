
public interface ActionListenerCommand {
	
	public void execute();

}

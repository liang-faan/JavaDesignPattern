public abstract class CD implements Packing{
public abstract String pack();
}//End of the CD class.

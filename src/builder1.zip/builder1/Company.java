public abstract class Company extends CD{
   public abstract int price();
}//End of the Company class.

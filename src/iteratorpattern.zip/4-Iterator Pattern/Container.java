
public interface Container {

	public Iterator getIterator();
	
}
